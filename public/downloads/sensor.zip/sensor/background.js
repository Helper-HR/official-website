// background.js —— 扩展中枢（眼睛+手都在浏览器内）。
// 读 DOM 找元素/算视口坐标（content.js，零足迹），用 CDP（chrome.debugger）发可信点击/滚动/移动。
// 在线授权校验 + 每日额度记账走后台 HTTPS。不再依赖桌面端 / 坐标校准 / 本地 WebSocket。
"use strict";

importScripts("license.js"); // 提供 self.verifyLicense（离线授权验签）

// 授权/管控后台（已上线）。该域名在 manifest host_permissions 里。
// 本地调试想连本机后台，可在侧边栏「高级 → 后台地址」临时改成 http://127.0.0.1:3000。
const DEFAULT_API_BASE = "https://admin.helper-hr.com";
const EXT_VERSION = chrome.runtime.getManifest().version;
const REPORT_EVERY = 5; // 每打 N 个上报一次用量（+循环结束兜底上报）
const OFFLINE_GRACE_MS = 24 * 3600 * 1000; // 离线宽限期：上次成功在线校验后 24h 内，断网也放行

async function getApiBase() {
  const { hrh_api_base } = await chrome.storage.local.get("hrh_api_base");
  return (hrh_api_base || DEFAULT_API_BASE).replace(/\/+$/, "");
}

// 点扩展图标 → 打开右侧侧边栏（替代会遮挡页面的弹窗）。
if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ===================== 授权（离线签名密钥 + 设备绑定） =====================
async function getDeviceId() {
  const { hrh_device_id } = await chrome.storage.local.get("hrh_device_id");
  if (hrh_device_id) return hrh_device_id;
  const buf = new Uint8Array(8);
  crypto.getRandomValues(buf);
  const id = Array.from(buf).map((b) => b.toString(16).padStart(2, "0")).join("");
  await chrome.storage.local.set({ hrh_device_id: id });
  return id;
}
async function checkLicense() {
  const deviceId = await getDeviceId();
  const { hrh_license } = await chrome.storage.local.get("hrh_license");
  const r = await verifyLicense(hrh_license || "", deviceId);
  return { deviceId, licensed: r.valid, reason: r.reason || null, payload: r.payload || null };
}

// ===================== 后台在线校验 / 用量上报（M3） =====================
// fetch 抛错 = 后台连不上（网络/未启动）→ 调用方走"离线兜底"（本地 license.js 验签，不下发额度）。
// 后台正常返回 valid:false 不抛错（属于"明确拒绝"，如吊销/过期/设备不符）。
async function verifyOnline() {
  const base = await getApiBase();
  const deviceId = await getDeviceId();
  const { hrh_license } = await chrome.storage.local.get("hrh_license");
  const r = await fetch(base + "/api/license/verify", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ deviceId, licenseToken: (hrh_license || "").replace(/\s+/g, ""), version: EXT_VERSION }),
  });
  if (r.status >= 500) throw new Error("后台错误 " + r.status); // 当作连不上 → 离线兜底
  const res = await r.json();
  // 记录在线校验结论，供离线宽限期判定：
  //   valid:true        → 刷新"上次在线成功"时间戳 + 清除停用标记
  //   deauthorized:true → 后台明确停用（吊销/删除/过期），离线也不再放行（堵复活漏洞）
  //   其它 valid:false（空/坏 token、设备不符）→ 不动标记（本地验签本就会拦，避免误标）
  if (res && res.valid === true) {
    await chrome.storage.local.set({ hrh_last_online_ok: Date.now(), hrh_deauthorized: false });
  } else if (res && res.deauthorized) {
    await chrome.storage.local.set({ hrh_deauthorized: true });
  }
  return res;
}

async function reportUsage(delta) {
  const base = await getApiBase();
  const deviceId = await getDeviceId();
  const r = await fetch(base + "/api/usage/report", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ deviceId, session: delta }),
  });
  return await r.json(); // {ok, recorded, remainingToday}
}

// 开循环前的授权闸：在线优先，连不上则离线兜底。
// 返回 { ok, online, remainingToday, dailyCap, name, error? }
async function licenseGate() {
  let res;
  try {
    res = await verifyOnline();
  } catch (e) {
    // 后台连不上 → 离线兜底 + 宽限期判定
    const { hrh_deauthorized, hrh_last_online_ok } =
      await chrome.storage.local.get(["hrh_deauthorized", "hrh_last_online_ok"]);
    // 上次在线时已被后台判停用（吊销/删除/过期）→ 离线也拦，防止断网复活
    if (hrh_deauthorized) return { ok: false, error: "该授权已被发放者停用（离线仍拦截）" };
    const local = await checkLicense();
    if (!local.licensed) return { ok: false, error: "未授权（离线）：" + (local.reason || "请填写授权密钥") };
    // 从未成功在线校验过 → 要求首次联网激活，避免拿张签名卡纯离线白嫖
    if (!hrh_last_online_ok) return { ok: false, error: "首次使用请先联网激活一次（连上后台校验）" };
    const ageMs = Date.now() - hrh_last_online_ok;
    if (ageMs > OFFLINE_GRACE_MS) {
      const h = Math.round(OFFLINE_GRACE_MS / 3600000);
      return { ok: false, error: `离线已超过 ${h} 小时，请联网激活后再用` };
    }
    return { ok: true, online: false, remainingToday: null, name: local.payload && local.payload.name };
  }
  if (!res.valid) return { ok: false, error: "未授权：" + (res.reason || "授权无效") };
  if (res.remainingToday != null && res.remainingToday <= 0) {
    return { ok: false, error: `今日额度已用完（每日上限 ${res.dailyCap}），明天再来或找发放者调额度` };
  }
  return {
    ok: true, online: true, registered: !!res.registered,
    remainingToday: res.remainingToday != null ? res.remainingToday : null,
    dailyCap: res.dailyCap != null ? res.dailyCap : null, name: res.name || null,
  };
}

// 给目标页 content 发消息；若因扩展重载导致 content 失联，则按需重新注入后重试。
async function sendToTab(tabId, msg) {
  try {
    return await chrome.tabs.sendMessage(tabId, msg);
  } catch (e) {
    try {
      await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
    } catch (e2) {
      throw new Error("注入 content 失败（该页不在 zhipin/file/localhost，或需勾选'允许访问文件网址'）：" + (e2.message || e2));
    }
    return await chrome.tabs.sendMessage(tabId, msg);
  }
}

// 读探查 + 定位第 index 个（1 起，默认 1）。move/click 共用。
async function probeTab({ tabId, selector, text, index }) {
  const r = await sendToTab(tabId, { type: "PROBE", selector, text, index });
  if (!r || !r.ok) return { ok: false, error: (r && r.error) || "探查失败（目标页没有 sensor content script？)" };
  return r;
}

// ===================== 只读探查（不点击，找选择器/数元素用） =====================
async function probeOnly({ tabId, selector, text, index }) {
  const r = await probeTab({ tabId, selector, text, index });
  if (!r.ok) return r;
  return {
    ok: true, count: r.count, index: r.index, frameUrl: r.frameUrl, docCount: r.docCount,
    center: r.center || null,
  };
}

// 识别"页面真实鼠标当前所指的元素"（找选择器用）：用 content 记录的页面最后鼠标位(视口坐标)
// → elementFromPoint（含同源 iframe 递归）。纯页内、零足迹，不依赖桌面端/校准。
async function inspectUnderMouse({ tabId }) {
  const m = await sendToTab(tabId, { type: "MOUSE_VP" });
  if (!m || !m.ok) return { ok: false, error: "没读到页面鼠标位置（先在该页面上挪一下鼠标）" };
  const r = await sendToTab(tabId, { type: "INSPECT", vx: m.x, vy: m.y });
  if (!r || !r.ok) return r || { ok: false, error: "inspect 失败" };
  return { ok: true, viewport: { vx: m.x, vy: m.y }, hit: r.hit, clickable: r.clickable, chain: r.chain };
}

// ===================== CDP 可信输入（chrome.debugger · 浏览器内替代桌面端真鼠标） =====================
// 经 DevTools Protocol 的 Input 域注入 isTrusted:true 的鼠标事件——页面无法分辨真假；
// 坐标用页内【顶层视口 CSS px】（content.js 的 center.cx/cy 已叠好同源 iframe 偏移），无需坐标校准。
// PoC：先验证可信点击 + 不被检测，再据此全量替换桌面端那套（desktop/WS/校准）。
const dbgAttached = new Set(); // 已附加调试器的 tabId

function dbgSend(tabId, method, params) {
  return new Promise((resolve, reject) => {
    chrome.debugger.sendCommand({ tabId }, method, params || {}, (res) => {
      const e = chrome.runtime.lastError;
      if (e) return reject(new Error(e.message));
      resolve(res);
    });
  });
}
async function dbgAttach(tabId) {
  if (dbgAttached.has(tabId)) return;
  await new Promise((resolve, reject) => {
    chrome.debugger.attach({ tabId }, "1.3", () => {
      const e = chrome.runtime.lastError;
      if (e) {
        if (/already attached/i.test(e.message || "")) { dbgAttached.add(tabId); return resolve(); }
        return reject(new Error(e.message)); // 多半是该页开了 F12（一个 tab 只能一个调试器）
      }
      dbgAttached.add(tabId);
      resolve();
    });
  });
}
async function dbgDetach(tabId) {
  if (!dbgAttached.has(tabId)) return;
  await new Promise((resolve) => chrome.debugger.detach({ tabId }, () => { void chrome.runtime.lastError; dbgAttached.delete(tabId); resolve(); }));
}
// 调试器被外部分离（用户开 F12、关页等）→ 同步清理本地状态
if (chrome.debugger && chrome.debugger.onDetach) {
  chrome.debugger.onDetach.addListener((src) => { if (src.tabId != null) dbgAttached.delete(src.tabId); });
}

// 可信点击：移动 → 按下 → 抬起（坐标=顶层视口 CSS px）。带轻微随机停顿，更像人手。
async function cdpClickAt(tabId, x, y) {
  await dbgAttach(tabId);
  const p = (a, b) => a + Math.floor(Math.random() * (b - a));
  await dbgSend(tabId, "Input.dispatchMouseEvent", { type: "mouseMoved", x, y, buttons: 0 });
  await sleep(p(30, 90));
  await dbgSend(tabId, "Input.dispatchMouseEvent", { type: "mousePressed", x, y, button: "left", buttons: 1, clickCount: 1 });
  await sleep(p(40, 110));
  await dbgSend(tabId, "Input.dispatchMouseEvent", { type: "mouseReleased", x, y, button: "left", buttons: 0, clickCount: 1 });
}

// 可信悬停/移动（坐标=顶层视口 CSS px）。
async function cdpMove(tabId, x, y) {
  await dbgAttach(tabId);
  await dbgSend(tabId, "Input.dispatchMouseEvent", { type: "mouseMoved", x, y, buttons: 0 });
}
// 可信滚轮（deltaY>0 向下滚）。x,y = 指针所在视口坐标（落在可滚动区域上）。
async function cdpScroll(tabId, x, y, deltaY) {
  await dbgAttach(tabId);
  await dbgSend(tabId, "Input.dispatchMouseEvent", { type: "mouseWheel", x, y, deltaX: 0, deltaY });
}

// PoC：探查第 index 个元素 → 在其中心做 CDP 可信点击（不经桌面端）。
async function cdpClickNth({ tabId, selector, text, index }) {
  const r = await probeTab({ tabId, selector, text, index });
  if (!r.ok) return r;
  if (!r.center) return { ok: false, error: `没有第 ${r.index} 个元素（共 ${r.count} 个）` };
  try {
    await cdpClickAt(tabId, r.center.cx, r.center.cy);
  } catch (e) {
    return { ok: false, error: "CDP 点击失败：" + ((e && e.message) || e) };
  }
  return { ok: true, index: r.index, count: r.count, viewport: r.center };
}

// ===================== 详情页打招呼循环（基础闭环：打招呼 → 下一个 → 重复） =====================
// 这版默认 greet-all。靠"打招呼按钮文字状态"驱动：点完变"继续沟通"=成功；翻页后又变回
// "打招呼"=新候选人已加载。姓名是 canvas 读不到，故不用姓名判重。
const GREET_SEL = ".dialog-lib-resume .btn-greet";
const NEXT_SEL = ".dialog-lib-resume .turn-btn.next";
const DETAIL_PANEL_SEL = ".dialog-lib-resume";        // 候选人详情弹窗（判断是否在详情页）
const CANDIDATE_SEL = ".candidate-card-wrap";          // 列表页候选人条目（点开打开详情）

// 拟人化默认参数（用户按 BOSS 经验校准：中等停留 + 轻度跳过 + 定期休息 + 单场≤50）
// 用户可在侧边栏改，覆盖值存 storage.hrh_human；循环每轮实时读取（运行中改也生效）。
const HUMAN_DEFAULTS = {
  readMinMs: 5000, readMaxMs: 18000,
  longReadProb: 0.15, longReadMinMs: 20000, longReadMaxMs: 45000,
  scrollMin: 1, scrollMax: 3,
  wanderMin: 1, wanderMax: 3,
  skipProb: 0.12,
  hesitateProb: 0.5, hesMinMs: 500, hesMaxMs: 2500,
  breakEveryMin: 8, breakEveryMax: 15, breakMinMs: 60000, breakMaxMs: 180000,
  distractProb: 0.05, distractMinMs: 30000, distractMaxMs: 120000,
  sessionCap: 100, // 内部安全硬顶（不在 UI 暴露）；超过即停，防单场过量
  readRegionSel: "#resume", panelSel: ".dialog-lib-resume",
};
async function getHuman() {
  const { hrh_human } = await chrome.storage.local.get("hrh_human");
  return Object.assign({}, HUMAN_DEFAULTS, hrh_human || {});
}
const rand = (a, b) => a + Math.random() * (b - a);
const rint = (a, b) => Math.round(rand(a, b));

let loop = { running: false, stop: false };
let loopKeepAlive = null; // 循环期间保活 SW（长"休息"期无 API 调用会被回收，每 20s 戳一下）

// 运行中工具栏图标闪动小红点：HR 切到别的标签也能看出任务在跑。
let badgeAnim = null;
function startBadge() {
  stopBadge();
  try { chrome.action.setBadgeBackgroundColor({ color: "#EF4444" }); } catch (e) {}
  let on = true;
  const tick = () => { try { chrome.action.setBadgeText({ text: on ? "•" : "" }); } catch (e) {} on = !on; };
  tick();
  badgeAnim = setInterval(tick, 600);
}
function stopBadge() {
  if (badgeAnim) { clearInterval(badgeAnim); badgeAnim = null; }
  try { chrome.action.setBadgeText({ text: "" }); } catch (e) {}
}

async function loopLog(line, cls) {
  const { hrh_loop_log = [] } = await chrome.storage.local.get("hrh_loop_log");
  hrh_loop_log.unshift({ t: Date.now(), line, cls: cls || "" });
  await chrome.storage.local.set({ hrh_loop_log: hrh_loop_log.slice(0, 50) });
}
async function setLoopState() {
  await chrome.storage.local.set({
    hrh_loop_state: {
      running: loop.running, greeted: loop.greeted || 0, skipped: loop.skipped || 0,
      pages: loop.pages || 0, target: loop.target || 0, dryRun: !!loop.dryRun, human: !!loop.human,
      online: !!loop.online, remainingToday: loop.remainingToday != null ? loop.remainingToday : null,
      dailyCap: loop.dailyCap != null ? loop.dailyCap : null, licName: loop.licName || null,
    },
  });
}

// 上报已积累的用量增量（每 REPORT_EVERY 个 或 强制）。失败不致命：把增量加回，下次再报。
async function maybeReport(force) {
  if (!loop.online) return; // 离线兜底不上报
  if (!force && loop.pendingGreeted < REPORT_EVERY) return;
  const delta = { greeted: loop.pendingGreeted || 0, skipped: loop.pendingSkipped || 0, pages: loop.pendingPages || 0 };
  if (!delta.greeted && !delta.skipped && !delta.pages) return;
  loop.pendingGreeted = 0; loop.pendingSkipped = 0; loop.pendingPages = 0;
  try {
    const r = await reportUsage(delta);
    if (r && r.remainingToday != null) loop.remainingToday = r.remainingToday;
  } catch (e) {
    loop.pendingGreeted += delta.greeted; loop.pendingSkipped += delta.skipped; loop.pendingPages += delta.pages;
  }
}

function startLoop(opts) {
  if (loop.running) return { ok: false, error: "循环已在运行" };
  const human = opts.human !== false; // 默认开
  let target = Math.max(1, parseInt(opts.target, 10) || 5);
  // 后台每日剩余额度是硬顶：本次目标 = min(用户目标, 今日剩余)。离线(remainingToday=null)不夹。
  const remainingToday = opts.remainingToday != null ? opts.remainingToday : null;
  if (remainingToday != null) target = Math.min(target, remainingToday);
  loop = {
    running: true, stop: false, tabId: opts.tabId,
    target,
    dryRun: !!opts.dryRun, human,
    online: !!opts.online, remainingToday, dailyCap: opts.dailyCap != null ? opts.dailyCap : null,
    licName: opts.licName || null,
    pendingGreeted: 0, pendingSkipped: 0, pendingPages: 0,
    greeted: 0, skipped: 0, pages: 0, skips: 0, iter: 0, calib: null,
    h: HUMAN_DEFAULTS, nextBreakAt: 0,
  };
  runLoop(); // 不 await，后台跑
  return { ok: true };
}
function stopLoop() { loop.stop = true; return { ok: true }; }

// 可中断 sleep（停顿期间能及时响应 stop）
async function sleepMs(ms) { const t0 = Date.now(); while (Date.now() - t0 < ms) { if (loop.stop) return; await sleep(200); } }

// ---- 拟人化动作 ----
async function getRegion(sel) {
  const r = await probeTab({ tabId: loop.tabId, selector: sel, index: 1 });
  return (r.ok && r.center && r.center.rect && r.center.rect.width > 4) ? r.center.rect : null;
}
// 在 rect（顶层视口坐标）内取随机点（带内边距，避免压边）。直接是视口坐标，CDP 用。
function randPointIn(rect, pad = 0.18) {
  const x = rect.left + rect.width * (pad + Math.random() * (1 - 2 * pad));
  const y = rect.top + rect.height * (pad + Math.random() * (1 - 2 * pad));
  return { x, y };
}
async function wander(rect, n) {
  if (!rect) return;
  for (let i = 0; i < n && !loop.stop; i++) {
    const p = randPointIn(rect);
    await cdpMove(loop.tabId, p.x, p.y);
    await sleepMs(rint(200, 900));
  }
}
// 阅读期：随机时长内 鼠标游走 + 简历区滚动 + 停顿
async function readingPhase() {
  const region = (await getRegion(loop.h.readRegionSel)) || (await getRegion(loop.h.panelSel));
  const dur = Math.random() < loop.h.longReadProb
    ? rint(loop.h.longReadMinMs, loop.h.longReadMaxMs)
    : rint(loop.h.readMinMs, loop.h.readMaxMs);
  await loopLog(`📖 拟人化-阅读 ${Math.round(dur / 1000)}s…`);
  const tEnd = Date.now() + dur;
  await wander(region, rint(loop.h.wanderMin, loop.h.wanderMax));
  const scrolls = rint(loop.h.scrollMin, loop.h.scrollMax);
  for (let i = 0; i < scrolls && !loop.stop && Date.now() < tEnd; i++) {
    const p = region ? randPointIn(region) : { x: 400, y: 360 };
    await cdpScroll(loop.tabId, p.x, p.y, rint(200, 500)); // 向下滚（deltaY>0）
    await sleepMs(rint(800, 2500));
    if (Math.random() < 0.3) { // 偶尔往回滚
      await cdpScroll(loop.tabId, p.x, p.y, -rint(150, 350));
      await sleepMs(rint(500, 1500));
    }
  }
  while (Date.now() < tEnd && !loop.stop) await sleep(200);
}
async function maybeHesitate() {
  if (Math.random() < loop.h.hesitateProb) await sleepMs(rint(loop.h.hesMinMs, loop.h.hesMaxMs));
}
async function longBreak() {
  const ms = rint(loop.h.breakMinMs, loop.h.breakMaxMs);
  await loopLog(`☕ 拟人化-休息 ${Math.round(ms / 1000)}s…`, "ok");
  await sleepMs(ms);
}
async function maybeDistract() {
  if (Math.random() < loop.h.distractProb) {
    const ms = rint(loop.h.distractMinMs, loop.h.distractMaxMs);
    await loopLog(`💤 拟人化-走神 ${Math.round(ms / 1000)}s…`);
    await sleepMs(ms);
  }
}
// 逼近并点击（CDP 可信）：先移动到位、轻微停顿再点（比直接点更像人手）。坐标=视口 center。
async function humanClick(center) {
  await cdpMove(loop.tabId, center.cx, center.cy);
  await sleepMs(rint(80, 300));
  await cdpClickAt(loop.tabId, center.cx, center.cy);
}

// 点完打招呼后，确认按钮不再是"打招呼"（变"继续沟通"=成功）
async function waitGreetConfirmed() {
  for (let i = 0; i < 16; i++) {
    await sleep(250);
    const r = await probeTab({ tabId: loop.tabId, selector: GREET_SEL, text: "打招呼", index: 1 });
    if (r.ok && r.count === 0) return true;
  }
  return false;
}
// 点完"下一个"后，等新候选人加载（按钮重新出现"打招呼"）
async function waitNextLoaded() {
  await sleep(rand(900, 1500));
  for (let i = 0; i < 14; i++) {
    if (loop.stop) return;
    const r = await probeTab({ tabId: loop.tabId, selector: GREET_SEL, text: "打招呼", index: 1 });
    if (r.ok && r.count > 0) return;
    await sleep(300);
  }
}

async function runLoop() {
  // 附加调试器（CDP 可信输入）。失败多半是该页开了 F12（一个 tab 只能一个调试器）。
  try { await dbgAttach(loop.tabId); }
  catch (e) { await loopLog("无法附加调试器（请先关掉该页的开发者工具 F12 再试）：" + ((e && e.message) || e), "err"); loop.running = false; await setLoopState(); return; }
  if (loopKeepAlive) clearInterval(loopKeepAlive);
  loopKeepAlive = setInterval(() => { try { chrome.runtime.getPlatformInfo(() => void chrome.runtime.lastError); } catch (e) {} }, 20000);
  startBadge(); // 工具栏图标开始闪动

  loop.h = await getHuman();
  loop.nextBreakAt = rint(loop.h.breakEveryMin, loop.h.breakEveryMax);
  await loopLog(`循环开始${loop.dryRun ? "（演练）" : ""}${loop.human ? "·拟人化" : ""}，目标 ${loop.target}`, "ok");
  await setLoopState();

  try {
    // 列表页开场：若详情弹窗未打开（即在推荐列表页），先 CDP 点可视区最上面的候选人条目，
    // 打开其详情，再走下面的详情页循环。详情已打开则跳过本步。
    let ready = true;
    if (!loop.stop) {
      const panel = await probeTab({ tabId: loop.tabId, selector: DETAIL_PANEL_SEL, index: 1 });
      if (!(panel.ok && panel.count > 0)) {
        await loopLog("列表页：点开第一个可见候选人…");
        const card = await sendToTab(loop.tabId, { type: "PROBE", selector: CANDIDATE_SEL, visibleTop: true });
        if (!(card && card.ok && card.center)) {
          await loopLog("没找到可视区内的候选人卡片（先滚到有候选人处再开始），停止", "err");
          ready = false;
        } else {
          await cdpClickAt(loop.tabId, card.center.cx, card.center.cy);
          let opened = false;
          for (let i = 0; i < 20 && !loop.stop; i++) {
            await sleep(300);
            const p = await probeTab({ tabId: loop.tabId, selector: DETAIL_PANEL_SEL, index: 1 });
            if (p.ok && p.count > 0) { opened = true; break; }
          }
          if (opened) await loopLog("✓ 已进入候选人详情，开始处理", "ok");
          else { await loopLog("点开候选人后详情未出现，停止", "err"); ready = false; }
        }
      }
    }

    while (ready && loop.running && !loop.stop) {
      loop.h = await getHuman(); // 每轮实时读参数（运行中改也生效）
      loop.iter++;
      if (loop.iter > loop.target * 8 + 80) { await loopLog("达最大迭代保护，停止", "err"); break; }
      if (!loop.dryRun && (loop.greeted >= loop.target || loop.greeted >= loop.h.sessionCap)) break;
      if (loop.dryRun && loop.pages >= loop.target) break;

      // 1. 阅读模拟（当前候选人已在屏上）
      if (loop.human) await readingPhase();
      else await sleepMs(rint(1500, 4000));
      if (loop.stop) break;

      // 2. 读打招呼按钮 + 决策
      const g = await probeTab({ tabId: loop.tabId, selector: GREET_SEL, text: "打招呼", index: 1 });
      const greetable = g.ok && g.count > 0 && g.center;

      if (loop.dryRun) {
        await loopLog(greetable ? "（演练）可打招呼，跳过不点" : "（演练）不可打招呼");
      } else if (greetable) {
        if (loop.human && Math.random() < loop.h.skipProb) {
          loop.skipped++; loop.pendingSkipped++;
          await loopLog(`⤳ 略过（模拟不合适），累计略过 ${loop.skipped}`);
        } else {
          if (loop.human) await maybeHesitate();
          await humanClick(g.center);
          if (await waitGreetConfirmed()) {
            loop.greeted++; loop.skips = 0; loop.pendingGreeted++;
            // 乐观本地扣减今日额度（每个都扣，界面即时变化）；每 REPORT_EVERY 个上报时由服务端值校正
            if (loop.online && loop.remainingToday != null) loop.remainingToday = Math.max(0, loop.remainingToday - 1);
            await loopLog(`✓ 已打招呼 ${loop.greeted}/${loop.target}`, "ok");
            await maybeReport(false);
            if (loop.online && loop.remainingToday != null && loop.remainingToday <= 0) {
              await loopLog("今日额度已用完，停止", "ok"); await setLoopState(); break;
            }
          } else {
            loop.skips++;
            await loopLog("⚠ 打招呼未确认（按钮没变），跳过", "err");
          }
        }
      } else {
        loop.skips++;
        await loopLog(`不可打招呼（已沟通/无按钮），跳过 (${loop.skips})`);
      }
      await setLoopState();

      if (loop.skips >= 10) { await loopLog("连续跳过过多，停止", "err"); break; }
      if (!loop.dryRun && (loop.greeted >= loop.target || loop.greeted >= loop.h.sessionCap)) break;

      // 3. 休息 / 走神（仅真实打招呼模式）
      if (loop.human && !loop.dryRun) {
        if (loop.greeted > 0 && loop.greeted >= loop.nextBreakAt) {
          await longBreak();
          loop.nextBreakAt = loop.greeted + rint(loop.h.breakEveryMin, loop.h.breakEveryMax);
        } else {
          await maybeDistract();
        }
      }
      if (loop.stop) break;

      // 4. 翻下一个
      const n = await probeTab({ tabId: loop.tabId, selector: NEXT_SEL, index: 1 });
      if (!(n.ok && n.center)) { await loopLog("找不到『下一个』按钮，停止", "err"); break; }
      await humanClick(n.center); // 人/非人都走 CDP（含移动+可信点击）
      loop.pages++; loop.pendingPages++;
      await loopLog(`→ 翻到下一个（第 ${loop.pages} 次）`);

      // 5. 等新候选人
      await waitNextLoaded();
    }
  } catch (e) {
    await loopLog("循环异常：" + ((e && e.message) || e), "err");
  }
  await maybeReport(true); // 结束兜底：把剩余未上报的增量补报
  if (loopKeepAlive) { clearInterval(loopKeepAlive); loopKeepAlive = null; }
  stopBadge(); // 停止图标闪动
  try { await dbgDetach(loop.tabId); } catch (e) {} // 结束就 detach，黄条消失
  loop.running = false;
  const reason = loop.stop ? "手动停止" : "完成/无更多";
  await loopLog(`循环结束（${reason}）：打招呼 ${loop.greeted}、略过 ${loop.skipped}、翻页 ${loop.pages}`, "ok");
  await setLoopState();
}

// ===================== 全局快捷键 =====================
// Alt+Shift+Z：识别页面真实鼠标下的元素（找选择器用，结果存到侧边栏『最近识别』）。
chrome.commands.onCommand.addListener((command) => {
  (async () => {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (command === "inspect-under-mouse") {
      let entry;
      try {
        if (!tab) entry = { t: Date.now(), error: "无活动标签页" };
        else {
          const r = await inspectUnderMouse({ tabId: tab.id });
          entry = r.ok
            ? { t: Date.now(), hit: r.hit, clickable: r.clickable, chain: r.chain }
            : { t: Date.now(), error: r.error };
        }
      } catch (e) { entry = { t: Date.now(), error: String((e && e.message) || e) }; }
      const { hrh_inspect_log = [] } = await chrome.storage.local.get("hrh_inspect_log");
      hrh_inspect_log.unshift(entry);
      await chrome.storage.local.set({ hrh_inspect_log: hrh_inspect_log.slice(0, 8) });
    }
  })();
});

// ===================== 消息路由（侧边栏） =====================
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      switch (msg.type) {
        case "PROBE_ONLY":
          sendResponse(await probeOnly(msg));
          break;
        case "INSPECT_UNDER_MOUSE":
          sendResponse(await inspectUnderMouse(msg));
          break;
        case "GET_HUMAN":
          sendResponse({ ok: true, config: await getHuman(), defaults: HUMAN_DEFAULTS });
          break;
        case "GET_LICENSE":
          sendResponse({ ok: true, ...(await checkLicense()) });
          break;
        case "SET_LICENSE": {
          await chrome.storage.local.set({ hrh_license: (msg.token || "").replace(/\s+/g, "") });
          sendResponse({ ok: true, ...(await checkLicense()) });
          break;
        }
        case "START_LOOP": {
          const gate = await licenseGate(); // 在线优先 + 离线兜底
          if (!gate.ok) { sendResponse({ ok: false, error: gate.error }); break; }
          sendResponse(startLoop({
            ...msg, online: gate.online, remainingToday: gate.remainingToday,
            dailyCap: gate.dailyCap, licName: gate.name,
          }));
          break;
        }
        case "ONLINE_STATUS": {
          // 侧边栏展示用：在线则返回后台状态，连不上返回 offline + 本地授权情况
          try {
            const res = await verifyOnline();
            sendResponse({ ok: true, online: true, ...res });
          } catch (e) {
            const local = await checkLicense();
            const { hrh_deauthorized, hrh_last_online_ok } =
              await chrome.storage.local.get(["hrh_deauthorized", "hrh_last_online_ok"]);
            sendResponse({
              ok: true, online: false, localLicensed: local.licensed, reason: local.reason,
              deauthorized: !!hrh_deauthorized, lastOnlineOk: hrh_last_online_ok || null,
              graceMs: OFFLINE_GRACE_MS,
            });
          }
          break;
        }
        case "GET_API_BASE":
          sendResponse({ ok: true, apiBase: await getApiBase(), defaultBase: DEFAULT_API_BASE });
          break;
        case "SET_API_BASE":
          await chrome.storage.local.set({ hrh_api_base: (msg.base || "").trim() });
          sendResponse({ ok: true, apiBase: await getApiBase() });
          break;
        case "STOP_LOOP":
          sendResponse(stopLoop());
          break;
        case "CDP_CLICK":
          sendResponse(await cdpClickNth(msg));
          break;
        case "CDP_DETACH":
          try { await dbgDetach(msg.tabId); sendResponse({ ok: true }); }
          catch (e) { sendResponse({ ok: false, error: String((e && e.message) || e) }); }
          break;
        default:
          sendResponse({ ok: false, error: "未知消息类型: " + msg.type });
      }
    } catch (e) {
      sendResponse({ ok: false, error: String((e && e.message) || e) });
    }
  })();
  return true; // 异步响应
});
