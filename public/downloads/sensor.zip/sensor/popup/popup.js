// popup.js —— 侧边栏控制台：授权、候选人批量处理、结果展示；（调试）CDP 点击/只读探查/识别。
"use strict";

const $ = (s) => document.querySelector(s);
const log = (t, cls) => {
  const el = $("#log");
  const c = cls === "err" ? "#c33" : cls === "ok" ? "#19914f" : "#455";
  el.innerHTML += `<div style="color:${c}">${t}</div>`;
  el.scrollTop = el.scrollHeight;
};

function send(msg) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(msg, (r) => {
      if (chrome.runtime.lastError) return resolve({ ok: false, error: chrome.runtime.lastError.message });
      resolve(r || { ok: false, error: "无响应" });
    });
  });
}

async function activeTabId() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab && tab.id;
}

// ---- 授权 ----
function renderLicense(s) {
  const el = $("#licState"), authDot = $("#authDot"), authText = $("#authText"), expVal = $("#expVal");
  if (s.deviceId) $("#deviceId").value = s.deviceId;
  if (s.licensed) {
    const p = s.payload || {};
    const exp = p.exp ? new Date(p.exp * 1000).toLocaleDateString() : "—";
    if (authDot) authDot.className = "dot success";
    if (authText) { authText.textContent = "授权正常"; authText.style.color = ""; }
    if (expVal) expVal.textContent = exp;
    if (el) { el.textContent = `已授权给「${p.name || "?"}」`; el.style.color = "var(--success)"; }
  } else {
    if (authDot) authDot.className = "dot danger";
    if (authText) { authText.textContent = "未授权"; authText.style.color = "var(--danger)"; }
    if (expVal) expVal.textContent = "—";
    if (el) { el.textContent = "✗ " + (s.reason || "请录入授权码"); el.style.color = "var(--danger)"; }
    const sec = $("#authSection"); if (sec) sec.open = true; // 未授权时自动展开授权区，方便首次录入
  }
}
// 打开插件时回填已保存的授权码（password 框里显示为圆点，不明文、不清空）
async function loadLicenseKey() {
  const { hrh_license } = await chrome.storage.local.get("hrh_license");
  if (hrh_license) $("#licKey").value = hrh_license;
}
$("#copyDevice").addEventListener("click", async () => {
  const v = $("#deviceId").value;
  if (v) { try { await navigator.clipboard.writeText(v); $("#copyDevice").textContent = "已复制"; setTimeout(() => ($("#copyDevice").textContent = "复制"), 1500); } catch (e) {} }
});
$("#btnLic").addEventListener("click", async () => {
  const token = $("#licKey").value.trim();
  const r = await send({ type: "SET_LICENSE", token });
  if (r.ok) renderLicense(r);
  loadOnline(); // 重新向后台查在线状态/额度（而不是只显示占位）
});

// ---- 在线状态 / 后台地址 ----
// 只显示有意义的在线信息：在线今日额度、后台拒绝、已被停用。
// 「后台未连接 / 离线兜底」等噪音一律不提示（留空）。授权与否由上面的 licState 负责。
function renderOnline(s) {
  const note = $("#onlineState"), quota = $("#quotaVal");
  const setNote = (t, c) => { if (note) { note.textContent = t || ""; note.style.color = c || ""; } };
  const setQuota = (t, c) => { if (quota) { quota.textContent = t; quota.style.color = c || ""; } };
  if (!s) return setNote("");
  if (!s.online) {
    if (s.deauthorized) { setQuota("已停用", "var(--danger)"); setNote("🚫 授权已被停用（无法开始）", "var(--danger)"); }
    else setNote(""); // 后台未连接/离线兜底等不提示；额度保持原值
    return;
  }
  if (!s.valid) { setQuota("—"); setNote("⚠ 后台拒绝：" + (s.reason || "授权无效"), "var(--danger)"); return; }
  if (s.remainingToday != null) {
    setQuota(`${s.remainingToday} / ${s.dailyCap}`, s.remainingToday > 0 ? "" : "var(--danger)");
    setNote("");
  } else setNote("");
}
async function loadOnline() {
  renderOnline();
  renderOnline(await send({ type: "ONLINE_STATUS" }));
}
async function loadApiBase() {
  const r = await send({ type: "GET_API_BASE" });
  if (r.ok) $("#apiBase").value = r.apiBase || "";
}
$("#btnSaveApi").addEventListener("click", async () => {
  const base = $("#apiBase").value.trim();
  const r = await send({ type: "SET_API_BASE", base });
  if (r.ok) { $("#apiBase").value = r.apiBase; loadOnline(); }
});

const idx = () => Math.max(1, parseInt($("#targetIndex").value, 10) || 1);
const sel = () => $("#targetSelector").value.trim() || undefined;
const tgtDesc = () => sel() ? `「${sel()}」` : `「${$("#targetText").value.trim()}」`;

$("#btnProbe").addEventListener("click", async () => {
  const tabId = await activeTabId();
  if (!tabId) return log("✗ 没有活动标签页", "err");
  const text = $("#targetText").value.trim(), index = idx(), selector = sel();
  log(`只读探查${tgtDesc()}第 ${index} 个…（不点击）`);
  const r = await send({ type: "PROBE_ONLY", tabId, text, index, selector });
  if (!r.ok) return log("✗ " + r.error, "err");
  log(`✓ 找到 ${r.count} 个 · 共 ${r.docCount} 个同源文档`, r.count > 0 ? "ok" : "err");
  if (r.frameUrl) log("  所在框架: " + r.frameUrl.replace(/^https?:\/\//, ""));
  if (r.center) {
    log(`  第 ${r.index} 个 顶层视口(${r.center.cx.toFixed(0)},${r.center.cy.toFixed(0)})`, "ok");
  } else log(`  ⚠ 没有第 ${index} 个（共 ${r.count} 个）`, "err");
});

$("#btnInspect").addEventListener("click", async () => {
  const tabId = await activeTabId();
  if (!tabId) return log("✗ 没有活动标签页", "err");
  log("识别鼠标下的元素…（先把真鼠标停在目标上）");
  const r = await send({ type: "INSPECT_UNDER_MOUSE", tabId });
  if (!r.ok) return log("✗ " + r.error, "err");
  const d = r.clickable || r.hit;
  if (!d) return log("  鼠标下没有元素（坐标可能超出页面）", "err");
  const fmtAttrs = Object.entries(d.attrs || {}).map(([k, v]) => `${k}="${v}"`).join(" ");
  log(`✓ <${d.tag}>${d.id ? " #" + d.id : ""}`, "ok");
  if (d.cls) log("  class: " + d.cls);
  if (fmtAttrs) log("  attr: " + fmtAttrs);
  if (d.text) log("  文本: " + d.text);
  if (d.frameUrl) log("  框架: " + d.frameUrl.replace(/^https?:\/\//, "").slice(0, 50));
  (r.chain || []).forEach((c, i) => {
    const cls = c.cls ? "." + c.cls.trim().replace(/\s+/g, ".") : "";
    log(`  祖先${i}: <${c.tag}>${cls}`);
  });
});

// ---- CDP 可信点击（浏览器内可信输入，免桌面端/免校准） ----
$("#btnCdpClick").addEventListener("click", async () => {
  const tabId = await activeTabId();
  if (!tabId) return log("✗ 没有活动标签页", "err");
  const text = $("#targetText").value.trim(), index = idx(), selector = sel();
  log(`CDP 可信点击第 ${index} 个${tgtDesc()}…（首次会弹"正在调试"黄条）`);
  const r = await send({ type: "CDP_CLICK", tabId, text, index, selector });
  if (!r.ok) return log("✗ " + r.error, "err");
  log(`✓ CDP 点击第 ${r.index} 个（共 ${r.count}）· 视口(${r.viewport.cx.toFixed(0)},${r.viewport.cy.toFixed(0)})`, "ok");
  log("  → 看靶页是否变化 + isTrusted 是否 true", "ok");
});
$("#btnCdpDetach").addEventListener("click", async () => {
  const tabId = await activeTabId();
  if (!tabId) return;
  await send({ type: "CDP_DETACH", tabId });
  log("已断开调试（黄条应消失）");
});

// ---- 最近识别（快捷键 Alt+Shift+Z 的结果，存在 storage） ----
function esc(s) {
  return String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
}
function fmtInspect(e) {
  if (e.error) return `<div style="color:#c33">✗ ${esc(e.error)}</div>`;
  const d = e.clickable || e.hit;
  if (!d) return `<div style="color:#c33">鼠标下无元素</div>`;
  const attrs = Object.entries(d.attrs || {}).map(([k, v]) => `${k}="${v}"`).join(" ");
  let s = '<div style="border-top:1px dashed #e3e8ef;padding:3px 0">';
  s += `<div style="color:#19914f">&lt;${esc(d.tag)}&gt;${d.id ? " #" + esc(d.id) : ""}</div>`;
  if (d.cls) s += `<div>class: ${esc(d.cls)}</div>`;
  if (attrs) s += `<div>attr: ${esc(attrs)}</div>`;
  if (d.text) s += `<div>文本: ${esc(d.text)}</div>`;
  if (e.chain && e.chain.length) {
    s += '<div style="color:#889;margin-top:2px">祖先链:</div>';
    e.chain.forEach((c, i) => {
      const a = Object.entries(c.attrs || {}).map(([k, v]) => `${k}="${v}"`).join(" ");
      const clsSel = c.cls ? "." + esc(c.cls).trim().replace(/\s+/g, ".") : "";
      s += `<div style="color:#667">${i}. &lt;${esc(c.tag)}&gt;${c.id ? " #" + esc(c.id) : ""}${clsSel}${a ? " [" + esc(a) + "]" : ""}</div>`;
    });
  }
  s += "</div>";
  return s;
}
async function renderInspectLog() {
  const { hrh_inspect_log = [] } = await chrome.storage.local.get("hrh_inspect_log");
  const box = $("#inspectLog");
  box.innerHTML = hrh_inspect_log.length
    ? hrh_inspect_log.map(fmtInspect).join("")
    : '<div style="color:#889">（空）鼠标停在元素上，按 Alt+Shift+Z</div>';
}
$("#clearInspect").addEventListener("click", async (e) => {
  e.preventDefault();
  await chrome.storage.local.remove("hrh_inspect_log");
  renderInspectLog();
});
// ---- 详情页打招呼循环 ----
$("#btnLoopStart").addEventListener("click", async () => {
  const tabId = await activeTabId();
  if (!tabId) return log("✗ 没有活动标签页", "err");
  const target = Math.max(1, parseInt($("#loopTarget").value, 10) || 1);
  const dryRun = $("#loopDry").checked;
  const human = true; // 系统默认且固定为拟人化操作（开关已移除）
  const r = await send({ type: "START_LOOP", tabId, target, dryRun, human });
  if (!r.ok) {
    log("✗ " + r.error, "err"); // 调试日志保留
    // 把启动失败（未授权/无额度/被停用等）显示到结果卡，避免“点了没反应”
    const title = $("#resultTitle"), sub = $("#resultSub"), dot = $("#resultDot");
    if (title) title.textContent = "无法开始";
    if (sub) { sub.textContent = r.error || "启动失败"; sub.style.color = "var(--danger)"; }
    if (dot) dot.className = "dot danger";
    return;
  }
  // 开始后：收起高级设置、展开详细记录，方便盯进度（toggle 监听会自动撑满日志框）
  if (advDetails && advDetails.open) advDetails.open = false;
  if (logDetails && !logDetails.open) logDetails.open = true;
});
$("#btnLoopStop").addEventListener("click", async () => {
  await send({ type: "STOP_LOOP" });
});

// 记住「处理人数」：关掉侧边栏再打开不复位
$("#loopTarget").addEventListener("change", () => {
  chrome.storage.local.set({ hrh_target: $("#loopTarget").value });
});
async function loadTarget() {
  const { hrh_target } = await chrome.storage.local.get("hrh_target");
  if (hrh_target) $("#loopTarget").value = hrh_target;
}

async function renderLoop() {
  const { hrh_loop_log = [], hrh_loop_state } = await chrome.storage.local.get(["hrh_loop_log", "hrh_loop_state"]);
  const s = hrh_loop_state;
  const setM = (id, v) => { const e = $(id); if (e) e.textContent = v; };
  const title = $("#resultTitle"), sub = $("#resultSub"), dot = $("#resultDot");
  const startBtn = $("#btnLoopStart"), stopBtn = $("#btnLoopStop");
  if (sub) sub.style.color = ""; // 清掉上次启动失败的红字

  if (s) {
    setM("#mProcessed", `${s.greeted}/${s.target}`);
    setM("#mGreeted", s.greeted);
    setM("#mSkipped", s.skipped || 0);
    setM("#mPages", s.pages);
    if (s.running) {
      if (title) title.textContent = "正在处理候选人" + (s.dryRun ? "（测试）" : "");
      if (sub) sub.textContent = `已处理 ${s.greeted}/${s.target}`;
      if (dot) dot.className = "dot busy";
    } else {
      const done = s.target > 0 && s.greeted >= s.target;
      if (title) title.textContent = done ? "本次任务已完成" : "任务已停止";
      if (sub) sub.textContent = `成功打招呼 ${s.greeted} 人，跳过 ${s.skipped || 0} 人`;
      if (dot) dot.className = "dot " + (done ? "success" : "warn");
    }
    // 循环上报后剩余额度会变，顺手同步状态卡的今日额度（用循环里的值，不额外请求后台）
    if (s.online && s.remainingToday != null) {
      renderOnline({ online: true, valid: true, remainingToday: s.remainingToday, dailyCap: s.dailyCap });
    }
  } else {
    setM("#mProcessed", "0/0"); setM("#mGreeted", "0"); setM("#mSkipped", "0"); setM("#mPages", "0");
    if (title) title.textContent = "暂无任务";
    if (sub) sub.textContent = "设置人数后点「开始处理」";
    if (dot) dot.className = "dot";
  }
  // 运行中：开始按钮禁用并显示“处理中…”，停止按钮可用
  if (startBtn) { startBtn.disabled = !!(s && s.running); startBtn.textContent = s && s.running ? "处理中…" : "开始处理"; }
  if (stopBtn) stopBtn.disabled = !(s && s.running);

  const box = $("#loopLog");
  if (box) box.innerHTML = hrh_loop_log.length
    ? hrh_loop_log.map((e) => `<div style="color:${e.cls === "err" ? "#c33" : e.cls === "ok" ? "#16A34A" : "#455"}">${esc(e.line)}</div>`).join("")
    : '<div style="color:#889">（暂无记录）</div>';
}

// ---- 拟人化参数面板 ----
// 内部存储单位：ms / 小数概率；界面显示：秒 / 百分比。data-htype 决定转换。
let HUMAN_DEFAULTS = null;
function fromStore(type, v) { return type === "sec" ? v / 1000 : type === "pct" ? Math.round(v * 100) : v; }
function toStore(type, v) { return type === "sec" ? Math.round(v * 1000) : type === "pct" ? v / 100 : Math.round(v); }

async function getHumanConfig() {
  return new Promise((res) => chrome.runtime.sendMessage({ type: "GET_HUMAN" }, (r) => res(r || {})));
}
async function loadParams() {
  const r = await getHumanConfig();
  if (!r.ok) return;
  HUMAN_DEFAULTS = r.defaults;
  const cfg = r.config;
  document.querySelectorAll("#paramPanel input[data-hkey]").forEach((inp) => {
    const k = inp.dataset.hkey, t = inp.dataset.htype;
    if (cfg[k] != null) inp.value = fromStore(t, cfg[k]);
    inp.step = t === "pct" ? "1" : t === "sec" ? "0.5" : "1";
    inp.min = "0";
    inp.type = "number";
  });
}
async function saveParams() {
  const out = {};
  document.querySelectorAll("#paramPanel input[data-hkey]").forEach((inp) => {
    const v = parseFloat(inp.value);
    if (!isNaN(v)) out[inp.dataset.hkey] = toStore(inp.dataset.htype, v);
  });
  await chrome.storage.local.set({ hrh_human: out });
}
document.querySelectorAll("#paramPanel input[data-hkey]").forEach((inp) => {
  inp.addEventListener("change", saveParams);
});
$("#resetParams").addEventListener("click", async (e) => {
  e.preventDefault();
  await chrome.storage.local.remove("hrh_human");
  loadParams();
});

// 快捷键/循环结果是后台异步写入的；弹窗开着时监听 storage 变化实时刷新
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes.hrh_inspect_log) renderInspectLog();
  if (changes.hrh_loop_log || changes.hrh_loop_state) renderLoop();
});

// ---- 调试模式开关（默认用户版；点右下角 ⚙ 进调试版，持久化） ----
function applyDebug(on) {
  const panel = $("#debugPanel");
  if (panel) panel.style.display = on ? "block" : "none";
  const g = $("#debugToggle");
  if (g) { g.style.color = on ? "#2b6cff" : "#cdd5e0"; g.title = on ? "调试模式（点击退出）" : "调试模式"; }
}
$("#debugToggle").addEventListener("click", async () => {
  const { hrh_debug_mode } = await chrome.storage.local.get("hrh_debug_mode");
  const next = !hrh_debug_mode;
  await chrome.storage.local.set({ hrh_debug_mode: next });
  applyDebug(next);
});

// ---- 详细记录展开时撑满到窗口底部；高级设置展开后自动滚到可见 ----
const logDetails = document.querySelector(".logdetails");
const advDetails = document.querySelector(".adv");
function fitLog() {
  const box = $("#loopLog");
  if (!logDetails || !box) return;
  if (logDetails.open) {
    const top = box.getBoundingClientRect().top;
    // 给底部「高级设置」卡留出空间（收起时按其实际高度，展开时按摘要条预留），使其仍可见
    const advH = advDetails ? (advDetails.open ? 52 : advDetails.offsetHeight) : 0;
    const reserve = advH + 26;
    box.style.maxHeight = Math.max(160, window.innerHeight - top - reserve) + "px";
  } else {
    box.style.maxHeight = "";
  }
}
if (logDetails) logDetails.addEventListener("toggle", () => {
  fitLog();
  if (logDetails.open) {
    logDetails.scrollIntoView({ behavior: "smooth", block: "start" });
    setTimeout(fitLog, 350); // 滚到位后按新位置再精确撑满到底
  }
});
window.addEventListener("resize", fitLog);
if (advDetails) advDetails.addEventListener("toggle", () => {
  if (advDetails.open) setTimeout(() => advDetails.scrollIntoView({ behavior: "smooth", block: "start" }), 50);
});

// 初始化：刷新各区
(async () => {
  chrome.storage.local.get("hrh_debug_mode").then(({ hrh_debug_mode }) => applyDebug(!!hrh_debug_mode));
  renderInspectLog();
  renderLoop();
  loadParams();
  loadApiBase();
  loadOnline();
  loadLicenseKey();
  loadTarget();
  send({ type: "GET_LICENSE" }).then((r) => { if (r.ok) renderLicense(r); });
})();
