// license.js —— 离线授权验签（ECDSA P-256），由 background 经 importScripts 载入。
// 私钥在发放者手里（tools/keygen.js），这里只内置公钥验签：全程离线、无服务器。
"use strict";

// 由 `node tools/keygen.js init` 生成后粘入。换私钥需同步更新这里。
// 注意：此公钥须与后台发卡私钥(server/.keys/private.json)配对。
// 当前为 server `npm run key:init` 生成的新密钥；若日后改用旧私钥，把这 4 个字段换回旧公钥。
// 旧公钥(备查)：x:"hyhYzj_JEKcnS_SurfdXBS5oY1qpYlSmRruS_PRslgo" y:"dusfhxDN5SUiL1WkJsEcSV40XFwVYgGLcM2ONAge5yo"
const PUBLIC_JWK = {
  kty: "EC",
  crv: "P-256",
  x: "rtAFb1qImSig_7cCmXnfsRtZe32XJDHBFIGRaZVqT4s",
  y: "_uWMfvwiTXHWqSyPJ1-FkvNmCuaIVo8gLTY2lA7rSM8",
};

function b64urlToBuf(s) {
  s = s.replace(/-/g, "+").replace(/_/g, "/");
  while (s.length % 4) s += "=";
  const bin = atob(s);
  const u = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
  return u;
}

let _pubKey = null;
async function getPubKey() {
  if (_pubKey) return _pubKey;
  _pubKey = await crypto.subtle.importKey("jwk", PUBLIC_JWK, { name: "ECDSA", namedCurve: "P-256" }, false, ["verify"]);
  return _pubKey;
}

// 校验密钥字符串。返回 { valid, reason?, payload? }
async function verifyLicense(token, deviceId) {
  token = (token || "").replace(/\s+/g, ""); // 去掉复制时混入的换行/空格
  if (!token || token.indexOf(".") < 0) return { valid: false, reason: "未填写授权密钥" };
  const [payloadB64, sigB64] = token.split(".");
  let payload;
  try { payload = JSON.parse(new TextDecoder().decode(b64urlToBuf(payloadB64))); }
  catch (e) { return { valid: false, reason: "密钥损坏" }; }
  let ok = false;
  try {
    const key = await getPubKey();
    ok = await crypto.subtle.verify({ name: "ECDSA", hash: "SHA-256" }, key, b64urlToBuf(sigB64), new TextEncoder().encode(payloadB64));
  } catch (e) { return { valid: false, reason: "验签出错：" + (e.message || e) }; }
  if (!ok) return { valid: false, reason: "签名无效（伪造或被篡改）", payload };
  if (payload.exp && Date.now() / 1000 > payload.exp) return { valid: false, reason: "授权已过期", payload };
  if (deviceId && Array.isArray(payload.devices) && payload.devices.length && !payload.devices.includes(deviceId)) {
    return { valid: false, reason: "本设备未授权（设备码不匹配）", payload };
  }
  return { valid: true, payload };
}

self.verifyLicense = verifyLicense;
