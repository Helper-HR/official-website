# HR Helper 扩展（sensor/）

BOSS 候选人批量处理助手。**全部在浏览器内完成**——读 DOM 找元素/算视口坐标（零足迹），用
**CDP（`chrome.debugger` → `Input.dispatchMouseEvent`）发可信输入（`isTrusted:true`）**点击/滚动/移动。
不再依赖桌面端程序、本地 WebSocket、坐标校准。

## 文件

| 文件 | 角色 |
|------|------|
| `manifest.json` | MV3 清单。权限含 `debugger`（CDP 可信输入）、`scripting`/`tabs`/`storage`/`sidePanel` |
| `content.js` | 注入目标页（顶层框架，`all_frames:false`）。**纯只读**：querySelector / getBoundingClientRect / 读同源 iframe。算顶层视口坐标（叠好 iframe 偏移）。零注入、零合成事件 |
| `background.js` | 中枢：CDP 输入（attach/click/scroll/move）+ 打招呼循环编排 + 拟人化 + 在线授权校验/额度上报（后台 HTTPS） |
| `license.js` | 离线授权验签（ECDSA P-256，内置公钥） |
| `popup/` | 侧边栏：授权、候选人批量处理、结果展示；⚙ 调试模式下有 CDP 点击/只读探查/识别元素 |
| `test-page.html` | 非 BOSS 靶页（验证 CDP 点击 `isTrusted`，开发用） |

## 工作原理

1. content.js 读 DOM → 目标元素的**顶层视口 CSS 坐标** `center.cx/cy`（同源 iframe 偏移已叠加）。
2. background.js `chrome.debugger.attach(tabId)` → `Input.dispatchMouseEvent`（mouseMoved→mousePressed→mouseReleased）在该坐标发**可信点击**；滚动用 `mouseWheel`。
3. 页面命中测试派发 `mousedown/click`，`isTrusted=true`，与真人一致。
4. 循环开始 attach（顶部出现"正在调试"黄条）、结束 detach。

> 坐标直接用视口 CSS px，无需任何校准；CDP 投递与标签是否前台无关（可切标签后台跑）。

## 授权/额度

开循环前 `licenseGate()` 在线校验（`POST /api/license/verify` → 今日剩余额度），连不上走离线兜底（本地验签 + 24h 宽限）。循环中每 5 个 `POST /api/usage/report`。后台见 [`../server`](../server)。

## 安全红线（BOSS 页）

- content.js **只读**：不 appendChild / 不改属性 / 不 dispatchEvent / 不覆盖原型。
- 点击经 CDP（浏览器输入管线），`isTrusted:true`，非合成事件。
- 行为拟人化（阅读/游走/滚动/犹豫/休息/走神）降低行为风控。
