// content.js —— 只读传感器（混合架构的"眼睛"，注入到目标页的顶层框架）。
// 零足迹铁律：只做 querySelector / 读文本 / getBoundingClientRect / 读 window 几何量。
//   ❌ 不 appendChild、不改属性、不 dispatchEvent、不 el.click()、不覆盖原型方法。
//
// 跨同源 iframe：BOSS 候选人列表在同源 iframe（zhipin.com/web/frame/recommend/）。
// 本脚本仅在顶层框架运行（manifest all_frames:false），通过 iframe.contentDocument 直接
// 读同源子框架 —— 子框架内零注入，比 all_frames:true 足迹更小、无多框架消息竞态。
// 子框架内元素的 getBoundingClientRect 是"子视口"坐标，需叠加 iframe 偏移换算回顶层视口，
// 才能套用校准的仿射变换（仿射是"顶层视口→屏幕"）。
(function () {
  "use strict";

  const CLICKABLE = "button, a, [role=button], input[type=button], input[type=submit]";

  // 顶层 + 所有同源 iframe 的 document（跨域访问抛错则跳过）
  function getAllDocuments() {
    const docs = [];
    const walk = (doc) => {
      docs.push(doc);
      let frames;
      try { frames = doc.querySelectorAll("iframe, frame"); } catch (e) { return; }
      frames.forEach((f) => {
        let d = null;
        try { d = f.contentDocument; } catch (e) { d = null; } // 跨域
        if (d) walk(d);
      });
    };
    walk(document);
    return docs;
  }

  // 元素所在同源 iframe 链相对顶层视口的累积偏移
  function frameOffset(el) {
    const off = { x: 0, y: 0 };
    let win = el.ownerDocument && el.ownerDocument.defaultView;
    while (win && win !== window.top) {
      let fe = null;
      try { fe = win.frameElement; } catch (e) { break; } // 跨域
      if (!fe) break;
      const r = fe.getBoundingClientRect();
      off.x += r.left;
      off.y += r.top;
      win = win.parent;
    }
    return off;
  }

  function isVisible(el) {
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0 && el.offsetParent !== null;
  }

  // 元素中心点，换算到【顶层视口】坐标（CSS px）
  function centerViewport(el) {
    const r = el.getBoundingClientRect();
    const o = frameOffset(el);
    const left = r.left + o.x, top = r.top + o.y;
    return {
      cx: left + r.width / 2,
      cy: top + r.height / 2,
      rect: { left, top, width: r.width, height: r.height },
    };
  }

  // 收集所有匹配元素（跨同源框架、可见、文档顺序≈视觉自上而下）。
  function collectMatches(selector, text) {
    const out = [];
    for (const doc of getAllDocuments()) {
      let cands;
      try { cands = doc.querySelectorAll(selector || CLICKABLE); } catch (e) { continue; }
      for (const e of cands) {
        const matchText = text ? (e.textContent || e.value || "").trim() === text : true;
        if (matchText && isVisible(e)) out.push({ el: e, doc });
      }
    }
    return out;
  }

  // 只读探查：统计匹配数量 + 取第 index 个（1 起）或【可视区内最上面一个】的顶层视口坐标。
  // 全程零点击零事件。visibleTop=true 时，跳过被滚出/被头部遮挡的，取中心在视口内、cy 最小的那个。
  function probe(selector, text, index, visibleTop) {
    const matches = collectMatches(selector, text);
    const out = {
      ok: true,
      count: matches.length,
      docCount: getAllDocuments().length,
      dpr: window.devicePixelRatio,
    };
    let pick = null;
    if (visibleTop) {
      const H = window.innerHeight, topMargin = 80; // 跳过吸顶头部区
      let bestY = Infinity;
      for (const m of matches) {
        const c = centerViewport(m.el);
        if (c.cy >= topMargin && c.cy <= H - 20 && c.cy < bestY) { bestY = c.cy; pick = m; out.center = c; }
      }
      out.index = 1;
      out.visibleTop = true;
    } else {
      const n = Math.max(1, parseInt(index, 10) || 1);
      out.index = n;
      pick = matches[n - 1];
      if (pick) out.center = centerViewport(pick.el);
    }
    if (pick) {
      try { out.frameUrl = pick.doc.location ? pick.doc.location.href : null; } catch (e) { out.frameUrl = null; }
    }
    return out;
  }

  // 命中点元素：从顶层视口坐标 (x,y) 取元素，遇同源 iframe 递归进去（坐标减去 iframe 偏移）。
  function deepElementFromPoint(doc, x, y) {
    let el = null;
    try { el = doc.elementFromPoint(x, y); } catch (e) { return null; }
    if (el && (el.tagName === "IFRAME" || el.tagName === "FRAME")) {
      let cd = null;
      try { cd = el.contentDocument; } catch (e) { cd = null; }
      if (cd) {
        const rr = el.getBoundingClientRect();
        const inner = deepElementFromPoint(cd, x - rr.left, y - rr.top);
        if (inner) return inner;
      }
    }
    return el;
  }

  // 命中元素往上 n 层的简要信息（图标类按钮的真正容器靠这个找）
  function ancestorChain(el, n) {
    const out = [];
    let cur = el;
    while (cur && cur.nodeType === 1 && out.length < n) {
      const cls = (typeof cur.className === "string" && cur.className) ||
        (cur.getAttribute && cur.getAttribute("class")) || null;
      const a = {};
      for (const k of ["aria-label", "title", "role"]) {
        const v = cur.getAttribute && cur.getAttribute(k);
        if (v) a[k] = v;
      }
      out.push({ tag: cur.tagName.toLowerCase(), id: cur.id || null, cls, attrs: a });
      cur = cur.parentElement;
    }
    return out;
  }

  // 向上找最近的可点击祖先（elementFromPoint 常命中按钮里的 span/svg）
  function nearestClickable(el) {
    let n = el;
    while (n && n.nodeType === 1) {
      try { if (n.matches && n.matches("button, a, [role=button], [onclick]")) return n; } catch (e) {}
      n = n.parentElement;
    }
    return null;
  }

  // 描述一个元素（只读）：tag/id/class/文本/常用属性/顶层视口中心/所在框架
  function describe(el) {
    if (!el || el.nodeType !== 1) return null;
    const cls = (typeof el.className === "string" && el.className) ||
      (el.getAttribute && el.getAttribute("class")) || null;
    const attrs = {};
    for (const a of ["aria-label", "title", "role", "type", "data-testid", "name"]) {
      const v = el.getAttribute && el.getAttribute(a);
      if (v) attrs[a] = v;
    }
    let frameUrl = null;
    try { frameUrl = el.ownerDocument.location ? el.ownerDocument.location.href : null; } catch (e) {}
    return {
      tag: el.tagName ? el.tagName.toLowerCase() : null,
      id: el.id || null,
      cls,
      text: (el.textContent || el.value || "").trim().slice(0, 40),
      attrs,
      center: centerViewport(el),
      frameUrl,
    };
  }

  // 自动校准：持续记录真鼠标在本页的最后位置（clientX/Y=视口坐标）。
  // 隔离世界被动监听，纯读、零足迹。鼠标在 iframe/侧栏/页面外时不更新。
  let _lastMouse = null;
  window.addEventListener("mousemove", (e) => {
    _lastMouse = { x: e.clientX, y: e.clientY, t: Date.now() };
  }, true);

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    try {
      if (msg.type === "PROBE") {
        sendResponse(probe(msg.selector, msg.text, msg.index, msg.visibleTop));
      } else if (msg.type === "INSPECT") {
        const hit = deepElementFromPoint(document, msg.vx, msg.vy);
        const clk = hit ? nearestClickable(hit) : null;
        sendResponse({ ok: true, hit: describe(hit), clickable: describe(clk), chain: hit ? ancestorChain(hit, 6) : [] });
      } else if (msg.type === "GEOMETRY") {
        sendResponse({
          ok: true, innerWidth, innerHeight, outerWidth, outerHeight,
          screenX: window.screenX, screenY: window.screenY, dpr: window.devicePixelRatio,
        });
      } else if (msg.type === "MOUSE_VP") {
        sendResponse({ ok: !!_lastMouse, ..._lastMouse });
      }
    } catch (e) {
      sendResponse({ ok: false, error: String((e && e.message) || e) });
    }
    return true;
  });
})();
